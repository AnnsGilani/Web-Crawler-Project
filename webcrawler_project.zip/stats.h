#ifndef STATS_H
#define STATS_H

struct Stats {
    long downloaded = 0;
    long processed  = 0;
    long discovered = 0;
    long saved_pages = 0;   // <-- REQUIRED
};

extern Stats stats;

#endif
