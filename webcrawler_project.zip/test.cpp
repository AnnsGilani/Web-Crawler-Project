#include <iostream>
#include <pthread.h>
#include <unistd.h>
#include "url_queue.h"

using namespace std;

URLQueue urlQueue;

void* producer(void*) {
    for (int i = 1; i <= 5; i++) {
        string url = "http://example.com/page" + to_string(i);
        cout << "[Producer] Enqueue: " << url << endl;
        urlQueue.enqueue(url);
        sleep(1);
    }
    return NULL;
}

void* consumer(void*) {
    for (int i = 1; i <= 5; i++) {
        string url = urlQueue.dequeue();
        cout << "[Consumer] Dequeue: " << url << endl;
        sleep(2);
    }
    return NULL;
}

int main() {
    pthread_t t1, t2;

    pthread_create(&t1, NULL, producer, NULL);
    pthread_create(&t2, NULL, consumer, NULL);

    pthread_join(t1, NULL);
    pthread_join(t2, NULL);

    return 0;
}

