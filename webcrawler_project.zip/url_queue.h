#ifndef URL_QUEUE_H
#define URL_QUEUE_H

#include <queue>
#include <string>
#include <pthread.h>

struct URLItem {
    std::string url;
    int depth;
};

class URLQueue {
private:
    std::queue<URLItem> q;
    pthread_mutex_t lock;
    pthread_cond_t cond;

public:
    URLQueue();
    void enqueue(const std::string &url, int depth);
    URLItem dequeue();
    bool isEmpty();
};

#endif
