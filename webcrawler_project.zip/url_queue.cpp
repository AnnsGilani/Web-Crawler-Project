#include "url_queue.h"
#include <pthread.h>

URLQueue::URLQueue() {
    pthread_mutex_init(&lock, NULL);
    pthread_cond_init(&cond, NULL);
}

void URLQueue::enqueue(const std::string &url, int depth) {
    pthread_mutex_lock(&lock);
    q.push({url, depth});
    pthread_cond_signal(&cond);
    pthread_mutex_unlock(&lock);
}

URLItem URLQueue::dequeue() {
    pthread_mutex_lock(&lock);
    while (q.empty()) {
        pthread_cond_wait(&cond, &lock);
    }
    URLItem item = q.front();
    q.pop();
    pthread_mutex_unlock(&lock);
    return item;
}

bool URLQueue::isEmpty() {
    pthread_mutex_lock(&lock);
    bool empty = q.empty();
    pthread_mutex_unlock(&lock);
    return empty;
}
