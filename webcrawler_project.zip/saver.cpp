#include "saver.h"
#include "stats.h"
#include "logger.h"
#include <fstream>
#include <sys/stat.h>
#include <pthread.h>

pthread_mutex_t save_lock = PTHREAD_MUTEX_INITIALIZER;

void save_page(const std::string &html) {
    pthread_mutex_lock(&save_lock);

    // Ensure pages/ folder exists
    mkdir("pages", 0777);

    stats.saved_pages++;

    std::string filename = "pages/page_" + std::to_string(stats.saved_pages) + ".html";

    std::ofstream file(filename);
    file << html;
    file.close();

    log_message("Saved page: " + filename);

    pthread_mutex_unlock(&save_lock);
}
