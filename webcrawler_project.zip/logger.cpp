#include "logger.h"
#include <fstream>
#include <pthread.h>
#include <ctime>
#include <cstring>

pthread_mutex_t log_lock = PTHREAD_MUTEX_INITIALIZER;

void log_message(const std::string &msg) {
    pthread_mutex_lock(&log_lock);

    std::ofstream file("crawler.log", std::ios::app);

    time_t now = time(0);
    char *dt = ctime(&now);
    dt[strlen(dt) - 1] = '\0'; // remove newline

    file << "[" << dt << "] " << msg << "\n";
    file.close();

    pthread_mutex_unlock(&log_lock);
}
