#include <iostream>
#include <string>
#include <vector>
#include <unordered_set>
#include <pthread.h>
#include <unistd.h>
#include <curl/curl.h>

#include "url_queue.h"
#include "parser.h"
#include "stats.h"
#include "logger.h"
#include "saver.h"

using namespace std;

// =============================================
// SETTINGS (you can modify)
// =============================================
int MAX_DEPTH = 2;         // how deep the crawler goes
int MAX_PAGES = 20;        // stop after N pages

// =============================================
// GLOBALS
// =============================================
URLQueue urlQueue;
unordered_set<string> visited;
pthread_mutex_t visited_lock = PTHREAD_MUTEX_INITIALIZER;

pthread_mutex_t worker_lock = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t shutdown_cond = PTHREAD_COND_INITIALIZER;

bool shutdown_flag = false;
int active_workers = 0;

string allowed_domain = "";

// =============================================
// CURL write callback
// =============================================
size_t write_callback(void* contents, size_t size, size_t nmemb, void* userp) {
    size_t total = size * nmemb;
    string* s = (string*)userp;
    s->append((char*)contents, total);
    return total;
}

// =============================================
// Download a webpage
// =============================================
string download_page(const string &url) {
    CURL *curl = curl_easy_init();
    string html;

    if (!curl) return html;

    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_callback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &html);
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 10L);

    CURLcode res = curl_easy_perform(curl);

    if (res != CURLE_OK) {
        log_message("ERROR downloading " + url);
    }

    curl_easy_cleanup(curl);
    return html;
}

// =============================================
// WORKER THREAD
// =============================================
void* worker(void* arg) {
    (void)arg;

    while (true) {
        pthread_mutex_lock(&worker_lock);
        if (shutdown_flag) {
            pthread_mutex_unlock(&worker_lock);
            break;
        }
        pthread_mutex_unlock(&worker_lock);

        // dequeue URLItem (this blocks)
        URLItem item = urlQueue.dequeue();
        string url = item.url;
        int depth = item.depth;

        // mark worker active
        pthread_mutex_lock(&worker_lock);
        active_workers++;
        pthread_mutex_unlock(&worker_lock);

        // avoid duplicates
        pthread_mutex_lock(&visited_lock);
        if (visited.count(url)) {
            pthread_mutex_unlock(&visited_lock);

            pthread_mutex_lock(&worker_lock);
            active_workers--;
            if (active_workers == 0 && urlQueue.isEmpty()) {
                shutdown_flag = true;
                pthread_cond_signal(&shutdown_cond);
            }
            pthread_mutex_unlock(&worker_lock);
            continue;
        }
        visited.insert(url);
        pthread_mutex_unlock(&visited_lock);

        // Log + download
        cout << "[Thread " << pthread_self() << "] Downloading: " << url << endl;
        log_message("Downloading: " + url);

        string html = download_page(url);

        cout << "[Thread " << pthread_self() << "] Downloaded "
             << html.size() << " bytes from " << url << endl;
        log_message("Downloaded (" + to_string(html.size()) + " bytes): " + url);

        stats.downloaded++;
        stats.processed++;

        // Save page if non-empty
        if (!html.empty()) {
            save_page(html);
        }

        // Maximum page limit
        if (stats.processed >= MAX_PAGES) {
            pthread_mutex_lock(&worker_lock);
            shutdown_flag = true;
            pthread_cond_signal(&shutdown_cond);
            pthread_mutex_unlock(&worker_lock);
        }

        // Depth limit → do NOT extract further links
        if (depth < MAX_DEPTH) {
            vector<string> links = extract_links(html, url);

            for (auto &link : links) {

                // Only http/https
                if (link.rfind("http://", 0) != 0 &&
                    link.rfind("https://", 0) != 0)
                    continue;

                // Domain restriction
                if (link.find(allowed_domain) == string::npos)
                    continue;

                pthread_mutex_lock(&visited_lock);
                bool is_new = !visited.count(link);
                pthread_mutex_unlock(&visited_lock);

                if (is_new) {
                    urlQueue.enqueue(link, depth + 1);
                    stats.discovered++;
                    log_message("Discovered new URL: " + link);
                }
            }
        }

        // Mark worker idle
        pthread_mutex_lock(&worker_lock);
        active_workers--;
        if (active_workers == 0 && urlQueue.isEmpty()) {
            shutdown_flag = true;
            pthread_cond_signal(&shutdown_cond);
        }
        pthread_mutex_unlock(&worker_lock);
    }
    return NULL;
}

// =============================================
// MAIN
// =============================================
int main(int argc, char** argv) {
    curl_global_init(CURL_GLOBAL_DEFAULT);

    string seed = "https://example.com";
    if (argc >= 2) seed = argv[1];

    // Extract allowed domain
    int pos = seed.find("://");
    string rest = (pos == string::npos) ? seed : seed.substr(pos + 3);
    allowed_domain = rest.substr(0, rest.find('/'));

    cout << "Domain restricted to: " << allowed_domain << endl;

    // seed insert
    urlQueue.enqueue(seed, 0);
    log_message("Seed URL added: " + seed);

    // Create worker threads
    const int NUM_THREADS = 4;
    pthread_t threads[NUM_THREADS];

    for (int i = 0; i < NUM_THREADS; i++)
        pthread_create(&threads[i], NULL, worker, NULL);

    // Wait for shutdown
    pthread_mutex_lock(&worker_lock);
    while (!shutdown_flag) {
        pthread_cond_wait(&shutdown_cond, &worker_lock);
    }
    pthread_mutex_unlock(&worker_lock);

    // Summary
    cout << "\n============ CRAWLER SHUTDOWN ============\n";
    cout << "Total URLs downloaded : " << stats.downloaded << endl;
    cout << "Total URLs processed  : " << stats.processed << endl;
    cout << "Total URLs discovered : " << stats.discovered << endl;
    cout << "Total unique visited  : " << visited.size() << endl;
    cout << "===========================================\n";

    log_message("Crawler shutting down.");

    for (int i = 0; i < NUM_THREADS; i++)
        pthread_join(threads[i], NULL);

    curl_global_cleanup();
    return 0;
}
