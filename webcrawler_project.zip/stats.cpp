#include "stats.h"

Stats stats;  // global definition
