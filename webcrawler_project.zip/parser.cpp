#include "parser.h"
#include <regex>
#include <string>
#include <vector>

using namespace std;

// Helper: join base URL and relative path
string join_url(const string &base, const string &path) {
    // base = https://books.toscrape.com
    // path = catalogue/page-2.html

    // If path is already absolute
    if (path.rfind("http://", 0) == 0 || path.rfind("https://", 0) == 0)
        return path;

    // Extract scheme + domain from base
    string prefix = base;
    int pos = prefix.find("://");
    if (pos != string::npos) {
        prefix = prefix.substr(pos + 3); // remove https://
    }
    prefix = base.substr(0, base.find(prefix)) + prefix.substr(0, prefix.find('/'));

    // Ensure prefix = https://books.toscrape.com
    if (prefix.back() == '/')
        prefix.pop_back();

    // If path starts with '/'
    if (!path.empty() && path[0] == '/')
        return prefix + path;

    // Otherwise relative path
    return prefix + "/" + path;
}

vector<string> extract_links(const string &html, const string &base_url) {
    vector<string> links;

    regex link_regex("<a[^>]*href=[\"']([^\"'>]+)[\"']", regex::icase);
    smatch match;

    string content = html;
    while (regex_search(content, match, link_regex)) {
        string raw = match[1];
        string full = join_url(base_url, raw);

        links.push_back(full);
        content = match.suffix();
    }

    return links;
}
