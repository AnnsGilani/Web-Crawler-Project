#ifndef SAVER_H
#define SAVER_H

#include <string>

void save_page(const std::string &html);

#endif
